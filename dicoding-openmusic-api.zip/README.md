# open-music-api-v1

fixed error on database (string name) -> increased string limit up to (30)

adding 'get songs by albumId and query parameters'